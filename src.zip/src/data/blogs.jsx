const blogs = [
  {
    id: 1,
    img: "/images/resource/blog/1.jpg",
    title: "Attract Sales And Profits ",
    blogSingleTitle:
      "Attract Sales And Profits toward the sunshine - and shadows will fall behind you.",
    blogText: `A job ravenously while Far much that one rank beheld after outside....`,
  },
  {
    id: 2,
    img: "/images/resource/blog/2.jpg",
    title: "5 Tips For Your Job Interviews",
    blogSingleTitle:
      "5 Tips For Your Job Interviews toward the sunshine - and shadows will fall behind you.",
    blogText: `A job ravenously while Far much that one rank beheld after outside....`,
  },
  {
    id: 3,
    img: "/images/resource/blog/3.jpg",
    title: "Overworked Newspaper Editor",
    blogSingleTitle:
      "Overworked Newspaper Editor toward the sunshine - and shadows will fall behind you.",
    blogText: `A job ravenously while Far much that one rank beheld after outside....`,
  },
  {
    id: 4,
    img: "/images/resource/blog/4.jpg",
    title: "Attract Sales And Profits",
    blogSingleTitle:
      "Attract Sales And Profits toward the sunshine - and shadows will fall behind you.",
    blogText: `A job ravenously while Far much that one rank beheld after outside....`,
  },
  {
    id: 5,
    img: "/images/resource/blog/5.jpg",
    title: "An Overworked Newspaper Editor",
    blogSingleTitle:
      "An Overworked Newspaper Editor toward the sunshine - and shadows will fall behind you.",
    blogText: `A job ravenously while Far much that one rank beheld after outside....`,
  },
  {
    id: 6,
    img: "/images/resource/blog/2.jpg",
    title: "The Best Account Providers",
    blogSingleTitle:
      "The Best Account Providers toward the sunshine - and shadows will fall behind you.",
    blogText: `A job ravenously while Far much that one rank beheld after outside....`,
  },
  {
    id: 7,
    img: "/images/resource/blog/1.jpg",
    title: (
      <>
        Free advertising for your
        <br /> online business
      </>
    ),
    blogSingleTitle:
      "Free advertising for your online business shadows will fall behind you.",
    blogText: `A job ravenously while Far much that one rank beheld after outside....`,
  },
  {
    id: 8,
    img: "/images/resource/blog/2.jpg",
    title: (
      <>
        Online business toward
        <br /> the sunshine
      </>
    ),
    blogSingleTitle:
      "Online business toward the sunshine - and shadows will fall behind you.",
    blogText: `A job ravenously while Far much that one rank beheld after outside....`,
  },
  {
    id: 9,
    img: "/images/resource/blog/3.jpg",
    title: (
      <>
        Advertising for your toward
        <br /> the sunshine
      </>
    ),
    blogSingleTitle:
      "Advertising for your toward the sunshine - and shadows will fall behind you.",
    blogText: `A job ravenously while Far much that one rank beheld after outside....`,
  },
  {
    id: 10,
    img: "/images/resource/blog/4.jpg",
    title: (
      <>
        Free advertising for your
        <br /> online business
      </>
    ),
    blogSingleTitle:
      "Free advertising for your toward the sunshine - and shadows will fall behind you.",
    blogText: `A job ravenously while Far much that one rank beheld after outside....`,
  },
  // home 10 blog
  {
    id: 11,
    img: "/images/resource/blog/2.jpg",
    title: "5 Tips For Your Job Interviews",
    blogSingleTitle:
      "5 Tips For Your Job Interviews the sunshine - and shadows will fall behind you.",
  },
  {
    id: 12,
    img: "/images/resource/blog/1.jpg",
    title: "2 Tips For Your Job Interviews",
    blogSingleTitle:
      "2 Tips For Your Job Interviews the sunshine - and shadows will fall behind you.",
  },
  {
    id: 13,
    img: "/images/resource/blog/3.jpg",
    title: "3 Tips For Your Job Interviews",
    blogSingleTitle:
      "3 Tips For Your Job Interviews the sunshine - and shadows will fall behind you.",
  },
  {
    id: 14,
    img: "/images/resource/blog/4.jpg",
    title: "6 Tips For Your Job Interviews",
    blogSingleTitle:
      "6 Tips For Your Job Interviews the sunshine - and shadows will fall behind you.",
  },
  {
    id: 15,
    img: "/images/resource/blog/5.jpg",
    title: "7 Tips For Your Job Interviews",
    blogSingleTitle:
      "7 Tips For Your Job Interviews the sunshine - and shadows will fall behind you.",
  },
];

export default blogs
