const IntroDescriptions = () => {
  return (
    <div className="text-box">
      <h4>About sentryspot</h4>
      <p>
        Far much that one rank beheld bluebird after outside ignobly allegedly
        more when oh arrogantly vehement irresistibly fussy penguin insect
        additionally wow absolutely crud meretriciously hastily dalmatian a
        glowered inset one echidna cassowary some parrot and much as goodness
        some froze the sullen much connected bat wonderfully on instantaneously
        eel valiantly petted this along across highhandedly much.
      </p>
      <p>
        Repeatedly dreamed alas opossum but dramatically despite expeditiously
        that jeepers loosely yikes that as or eel underneath kept and slept
        compactly far purred sure abidingly up above fitting to strident wiped
        set waywardly far the and pangolin horse approving paid chuckled
        cassowary oh above a much opposite far much hypnotically more therefore
        wasp less that hey apart well like while superbly orca and far hence
        one.Far much that one rank beheld bluebird after outside ignobly
        allegedly more when oh arrogantly vehement irresistibly fussy.
      </p>
    </div>
  );
};

export default IntroDescriptions;
