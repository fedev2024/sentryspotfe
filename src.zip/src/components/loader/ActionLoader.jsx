import React from "react";

const ActionLoader = () => {
  return <span class="loader"></span>;
};

export default ActionLoader;
