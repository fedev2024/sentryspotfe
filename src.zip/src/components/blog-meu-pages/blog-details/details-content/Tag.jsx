const Tag = () => {
  return (
    <div className="tags">
      <a href="#">App</a>
      <a href="#">Design</a>
      <a href="#">Digital</a>
    </div>
  );
};

export default Tag;
